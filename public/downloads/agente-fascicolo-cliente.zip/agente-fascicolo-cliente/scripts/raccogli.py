#!/usr/bin/env python3
"""Mette il materiale sparso di un cliente in un unico file ordinato per data.

Non riassume e non taglia niente: serve solo a non far leggere all'agente venti
file in ordine casuale. Nessuna dipendenza, gira con Python 3.8+.

    python3 raccogli.py ~/clienti/rossi --cliente "Studio Rossi" --out contesto.md
"""

import argparse
import email
import email.policy
import email.utils
import os
import re
import sys
from datetime import datetime, timezone

ESTENSIONI = {".md", ".txt", ".eml", ".markdown", ".text", ".log"}
MAX_BYTE = 2_000_000

# 2026-08-03, 03/08/2026, 03-08-2026, 3 agosto 2026
MESI = {
    "gennaio": 1, "febbraio": 2, "marzo": 3, "aprile": 4, "maggio": 5,
    "giugno": 6, "luglio": 7, "agosto": 8, "settembre": 9, "ottobre": 10,
    "novembre": 11, "dicembre": 12,
}
RE_ISO = re.compile(r"\b(20\d{2})[-/](\d{1,2})[-/](\d{1,2})\b")
RE_IT = re.compile(r"\b(\d{1,2})[-/.](\d{1,2})[-/.](20\d{2})\b")
RE_ESTESA = re.compile(r"\b(\d{1,2})\s+(" + "|".join(MESI) + r")\s+(20\d{2})\b", re.I)


def _valida(anno, mese, giorno):
    try:
        return datetime(anno, mese, giorno)
    except ValueError:
        return None


def data_dal_testo(testo):
    """Prima data plausibile trovata nel testo, o None."""
    finestra = testo[:4000]
    for regex, ordine in ((RE_ISO, "ymd"), (RE_IT, "dmy")):
        for m in regex.finditer(finestra):
            a, b, c = (int(x) for x in m.groups())
            d = _valida(a, b, c) if ordine == "ymd" else _valida(c, b, a)
            if d:
                return d
    m = RE_ESTESA.search(finestra)
    if m:
        return _valida(int(m.group(3)), MESI[m.group(2).lower()], int(m.group(1)))
    return None


def leggi_eml(percorso):
    """(data, intestazione, corpo) da un file .eml. Data None se assente."""
    with open(percorso, "rb") as f:
        msg = email.message_from_binary_file(f, policy=email.policy.default)

    data = None
    if msg.get("Date"):
        try:
            dt = email.utils.parsedate_to_datetime(msg["Date"])
            data = dt.astimezone(timezone.utc).replace(tzinfo=None) if dt.tzinfo else dt
        except (TypeError, ValueError):
            data = None

    corpo = ""
    try:
        parte = msg.get_body(preferencelist=("plain",))
        if parte is not None:
            corpo = parte.get_content()
    except Exception:
        corpo = ""
    if not corpo:
        corpo = "[corpo non leggibile in testo semplice]"

    intestazione = "\n".join(
        f"{etichetta}: {msg.get(campo)}"
        for etichetta, campo in (("Da", "From"), ("A", "To"), ("Oggetto", "Subject"))
        if msg.get(campo)
    )
    return data, intestazione, corpo.strip()


def leggi_testo(percorso):
    with open(percorso, "r", encoding="utf-8", errors="replace") as f:
        return f.read().strip()


def raccogli(cartella):
    pezzi, saltati = [], []
    for radice, dirs, files in os.walk(cartella):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for nome in sorted(files):
            if nome.startswith("."):
                continue
            percorso = os.path.join(radice, nome)
            if os.path.splitext(nome)[1].lower() not in ESTENSIONI:
                saltati.append((percorso, "estensione non gestita"))
                continue
            try:
                if os.path.getsize(percorso) > MAX_BYTE:
                    saltati.append((percorso, "file troppo grande"))
                    continue
                if nome.lower().endswith(".eml"):
                    data, intestazione, corpo = leggi_eml(percorso)
                else:
                    corpo = leggi_testo(percorso)
                    intestazione = ""
                    data = data_dal_testo(corpo)
            except (OSError, UnicodeError) as e:
                saltati.append((percorso, f"non leggibile: {e}"))
                continue

            if not corpo:
                saltati.append((percorso, "vuoto"))
                continue

            certa = data is not None
            if data is None:
                data = datetime.fromtimestamp(os.path.getmtime(percorso))
            pezzi.append(
                {
                    "percorso": os.path.relpath(percorso, cartella),
                    "data": data,
                    "certa": certa,
                    "intestazione": intestazione,
                    "corpo": corpo,
                }
            )
    pezzi.sort(key=lambda p: p["data"])
    return pezzi, saltati


def componi(pezzi, saltati, cliente):
    oggi = datetime.now().strftime("%Y-%m-%d")
    out = [f"# Materiale grezzo — {cliente}", ""]
    if pezzi:
        primo = pezzi[0]["data"].strftime("%d/%m/%Y")
        ultimo = pezzi[-1]["data"].strftime("%d/%m/%Y")
        out.append(f"{len(pezzi)} file, dal {primo} al {ultimo}. Raccolto il {oggi}.")
    else:
        out.append(f"Nessun file utilizzabile. Raccolto il {oggi}.")
    out += [
        "",
        "Ordinato per data. Le date marcate `(dedotta dal file)` vengono dalla data di",
        "modifica, non dal contenuto: trattale come incerte.",
        "",
    ]

    for i, p in enumerate(pezzi, 1):
        nota = "" if p["certa"] else " (dedotta dal file)"
        out += [
            "---",
            "",
            f"## [{i}] {p['percorso']}",
            f"**Data:** {p['data'].strftime('%d/%m/%Y')}{nota}",
        ]
        if p["intestazione"]:
            out += ["", "```", p["intestazione"], "```"]
        out += ["", p["corpo"], ""]

    if saltati:
        out += ["---", "", "## File saltati", ""]
        out += [f"- `{os.path.basename(p)}` — {motivo}" for p, motivo in saltati]
        out.append("")
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="Raccoglie il materiale di un cliente in un unico file.")
    ap.add_argument("cartella", help="cartella con mail esportate, appunti, note")
    ap.add_argument("--cliente", required=True, help="nome del cliente")
    ap.add_argument("--out", default="contesto.md", help="file di destinazione")
    args = ap.parse_args()

    if not os.path.isdir(args.cartella):
        sys.exit(f"Non è una cartella: {args.cartella}")

    pezzi, saltati = raccogli(args.cartella)
    if not pezzi:
        print("Nessun file leggibile trovato.", file=sys.stderr)
        print(f"Estensioni gestite: {', '.join(sorted(ESTENSIONI))}", file=sys.stderr)

    with open(args.out, "w", encoding="utf-8") as f:
        f.write(componi(pezzi, saltati, args.cliente))

    print(f"{len(pezzi)} file raccolti in {args.out}" + (f", {len(saltati)} saltati" if saltati else ""))


if __name__ == "__main__":
    main()
