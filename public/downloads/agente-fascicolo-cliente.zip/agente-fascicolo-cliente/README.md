# Fascicolo cliente

Un agente che prende il materiale sparso di un cliente e ti restituisce lo stato:
cosa è deciso, cosa è aperto, cosa scade, di chi è la prossima mossa.

Serve quando hai una call fra dieci minuti e non hai riletto niente.

## Cosa c'è dentro

```
SKILL.md               le istruzioni dell'agente
scripts/raccogli.py    mette i file sparsi in un unico contesto ordinato per data
TEMPLATE-fascicolo.md  il formato dell'output
esempio/               materiale finto e il fascicolo che ne deve uscire
```

## Se hai Claude Code

Copia la cartella dentro `.claude/skills/` del tuo progetto, oppure in
`~/.claude/skills/` per averla ovunque:

```
cp -r agente-fascicolo-cliente ~/.claude/skills/fascicolo-cliente
```

Riavvia Claude Code e chiedi: **"fammi il fascicolo del cliente Rossi, il
materiale sta in ~/clienti/rossi"**. La skill parte da sola.

## Se non hai Claude Code

Funziona lo stesso su Claude via browser. Apri un Progetto nuovo, carica
`SKILL.md` e `TEMPLATE-fascicolo.md` nella knowledge del progetto, poi incolla
il materiale del cliente in chat e chiedi il fascicolo.

Perdi lo script di raccolta, che è la parte comoda ma non quella importante.

## Provalo prima sull'esempio

```
python3 scripts/raccogli.py esempio/materiale --cliente "Esempio Srl" --out contesto.md
```

Poi dai `contesto.md` all'agente e confronta quello che ti restituisce con
`esempio/fascicolo-atteso.md`. Non deve venire identico, ma le tre cose che
contano devono esserci: la firma ferma da otto settimane, il csv mai arrivato,
e il budget della fase 2 in aperto e non in deciso. Se te le mette in "deciso",
il fascicolo sta inventando e non ti puoi fidare.

## Una cosa sola da sapere

L'agente ha una regola dura: se una cosa non è scritta da nessuna parte, non
esiste. Non riempie i buchi con quello che è ragionevole supporre, li dichiara.
È il motivo per cui ci si può andare in call.

---

Costruito da Maby Prochilo · [mprochilo.it](https://mprochilo.it)
Ogni settimana su [Oltre il prompt](https://oltreilprompt.substack.com) esce
una cosa così, spiegata da dentro.
