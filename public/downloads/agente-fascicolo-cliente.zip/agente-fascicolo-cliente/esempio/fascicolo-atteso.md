# Fascicolo — Esempio Srl

Aggiornato al 03/08/2026 · ricostruito da 4 file, dal 12/05/2026 al 30/06/2026

## In una riga

La fase 1 è approvata a voce ma non firmata da due mesi, e il file che serve per
iniziare non è mai arrivato: il progetto è fermo su di loro, non su di noi.

## Deciso

| Cosa | Quando | Da dove risulta |
|---|---|---|
| Si parte dal listino come fonte unica dei prezzi, non dal form | 12/05/2026 | 01-call-kickoff.md, accordo in call |
| Fase 1 approvata, 6.400 euro, quattro settimane dalla firma | 04/06/2026 | 03-risposta-andrea.eml, "fase 1 ok, procediamo" |
| Il follow-up automatico a 7 giorni resta fuori dalle due fasi | 25/05/2026 | 02-proposta.eml, confermato mai contestato |

## Aperto

| Cosa | Ferma da | Cosa la sblocca |
|---|---|---|
| Firma del contratto fase 1 | 8 settimane (attesa "settimana prossima" il 04/06) | Il rientro della titolare, mai confermato |
| Export csv del listino | 5 settimane (Giulia ha richiamata lei il 30/06) | Giulia deve decidere quale dei tre file è quello buono |
| Fase 2, 9.000 euro | Rimandata esplicitamente il 04/06 | I tempi della fase 2, che si stimano solo a fase 1 chiusa |

## Scade

| Cosa | Data | Certezza |
|---|---|---|
| Quattro settimane di consegna fase 1, contate dalla firma | Nessuna data assoluta finché non firmano | vaga |

## Prossima mossa

**Tocca a me:** niente. Ho già chiesto csv e firma, l'ultima sollecitazione è del 30/06.

**Tocca a loro:** firma (Andrea, ferma da 8 settimane) e csv del listino (Giulia, ferma da 5).

**Palla ferma:** sì. Due persone diverse aspettano una terza (la titolare) e nessuno
dei due ha detto quando rientra. Nessuno si è più fatto vivo dopo il 30/06.

## Buchi

Non risulta nessuno scambio dopo il 30/06/2026: cinque settimane senza materiale.
Se ci sono stati messaggi o telefonate in mezzo, il fascicolo non li vede e la
riga "palla ferma" potrebbe essere sbagliata.

Il budget della fase 2 è dato per accettato ("il numero non è un problema") ma
non è mai stato approvato: resta in aperto, non in deciso.
