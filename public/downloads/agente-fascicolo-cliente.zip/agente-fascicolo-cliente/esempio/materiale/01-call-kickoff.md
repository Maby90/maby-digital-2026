# Call kickoff — 12/05/2026

Presenti: io, Andrea (operations), Giulia (marketing).

Vogliono rifare il flusso di preventivazione. Oggi arriva una richiesta via form,
qualcuno la legge, apre un file, copia i dati a mano, manda il preventivo. Ci
mettono in media due giorni e mezzo. Andrea dice che il problema vero non è il
tempo, è che il 20% dei preventivi esce con il listino vecchio.

Concordato: partiamo dal listino, non dal form. Prima si sistema la fonte unica
dei prezzi, poi si automatizza.

Giulia chiede se si può agganciare anche il follow-up automatico a 7 giorni.
Ho detto che si può ma non in questa fase. Rimandato.

Budget: non ne abbiamo parlato. Andrea ha detto "vediamo la proposta".
