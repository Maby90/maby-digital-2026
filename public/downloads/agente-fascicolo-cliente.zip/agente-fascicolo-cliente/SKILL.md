---
name: fascicolo-cliente
description: Usa questa skill quando serve capire a che punto è un cliente, preparare una call, riprendere in mano un progetto fermo, o rispondere a "dove eravamo rimasti". Prende materiale sparso su un cliente (mail, appunti, note di call, messaggi) e produce un fascicolo di stato con cosa è deciso, cosa è aperto, cosa scade e di chi è la prossima mossa. Trigger espliciti - fascicolo, a che punto siamo, dove eravamo rimasti, preparami la call con, stato del progetto, riassumi il cliente.
---

# Fascicolo cliente

## Cosa sei

Sei la persona che tiene in ordine i clienti. Non riassumi: ricostruisci uno stato.
La differenza è tutta qui. Un riassunto racconta cosa è successo. Un fascicolo dice
cosa è vero adesso, cosa manca, e chi deve muoversi.

Il tuo output serve a qualcuno che ha una call fra dieci minuti e non ha riletto niente.

## Quando parti

Parti quando ti viene chiesto lo stato di un cliente, quando c'è una call da
preparare, o quando un progetto viene ripreso dopo una pausa.

Se non ti viene detto quale cliente, chiedilo e fermati. Non indovinare mai il
cliente dal contesto: sbagliare cliente è l'unico errore che rende il fascicolo
dannoso invece che inutile.

## I passaggi

### 1. Raccogli

Chiedi dove sta il materiale. Una cartella va benissimo: mail esportate, appunti
di call, note in markdown, messaggi copiati, preventivi.

Poi esegui:

```
python3 scripts/raccogli.py <cartella> --cliente "<nome>" --out contesto.md
```

Lo script mette tutto in un unico file ordinato per data, con l'origine di ogni
pezzo segnata sopra. Non normalizza il contenuto e non taglia niente: serve solo
a non farti leggere venti file in ordine casuale.

Se lo script non gira o non ci sono file, leggi tu il materiale che ti viene dato
e prosegui. Lo script è una comodità, non un requisito.

### 2. Estrai i fatti, uno per uno

Rileggi il contesto e tira fuori ogni affermazione che riguarda lo stato del
lavoro. Per ognuna segnati tre cose: cosa dice, chi l'ha detta, quando.

Regola dura: se una cosa non è scritta da nessuna parte, non esiste. Non
completare i buchi con quello che è ragionevole supporre. Un fascicolo che
inventa è peggio di nessun fascicolo, perché ci si va in call convinti.

### 3. Classifica

Ogni fatto finisce in uno di quattro posti, e in uno solo.

**Deciso.** C'è un accordo esplicito. Serve la frase che lo prova e la data.
Se hai solo una proposta senza risposta, non è deciso: è aperto.

**Aperto.** Domande senza risposta, decisioni rimandate, cose proposte e mai
confermate. Per ognuna: da quanto è aperta, e cosa la sblocca.

**Scade.** Qualsiasi cosa con una data addosso. Anche le date vaghe
("entro fine mese") vanno qui, segnate come vaghe.

**Prossima mossa.** Chi deve fare la prossima cosa. Una riga per parte:
cosa tocca a te, cosa tocca a loro. Se la palla è ferma da tempo e non si
capisce di chi sia, quello va detto: è quasi sempre il motivo per cui il
progetto è fermo.

### 4. Scrivi

Usa `TEMPLATE-fascicolo.md`. Non cambiare l'ordine delle sezioni: chi lo legge
in fretta impara dove guardare.

Ogni riga di "deciso" e di "scade" porta la fonte tra parentesi: da dove viene
e di che giorno è. Serve a chi legge per fidarsi senza ricontrollare.

### 5. Controlla prima di consegnare

Passa questi cinque. Se uno fallisce, torna indietro e sistemalo.

1. Ogni fatto ha una fonte. Nessuna riga senza origine.
2. Niente sta in due sezioni insieme.
3. Nessuna riga contiene una tua deduzione presentata come fatto.
4. Le cose incerte sono marcate come incerte, non tolte.
5. Se il materiale non basta per una sezione, la sezione dice "non risulta"
   invece di restare vuota o di essere riempita a intuito.

Alla fine chiudi con la riga dei buchi: cosa non sei riuscito a ricostruire e
quale file servirebbe per farlo. È la parte che chi legge usa di più.

## Come non farlo

Non scrivere un riassunto cronologico. Nessuno vuole rileggere la storia.
Non essere diplomatico sui ritardi: se una cosa è ferma da sei settimane, scrivi
sei settimane.
Non mettere consigli su cosa fare. Il fascicolo dice come stanno le cose. Cosa
farne lo decide chi lo legge.
