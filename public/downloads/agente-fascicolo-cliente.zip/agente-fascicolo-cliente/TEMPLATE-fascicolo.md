# Fascicolo — {{CLIENTE}}

Aggiornato al {{DATA}} · ricostruito da {{N}} file, dal {{DATA_PRIMO}} al {{DATA_ULTIMO}}

## In una riga

{{Dove sta il progetto adesso e qual è la cosa che lo tiene fermo o che lo fa avanzare. Una frase, senza aggettivi.}}

## Deciso

| Cosa | Quando | Da dove risulta |
|---|---|---|
| {{fatto}} | {{data}} | {{file, riga o mittente}} |

## Aperto

| Cosa | Ferma da | Cosa la sblocca |
|---|---|---|
| {{questione}} | {{giorni o settimane}} | {{la risposta di X, il documento Y}} |

## Scade

| Cosa | Data | Certezza |
|---|---|---|
| {{scadenza}} | {{data}} | {{certa / vaga}} |

## Prossima mossa

**Tocca a me:** {{cosa, entro quando}}

**Tocca a loro:** {{cosa, da quanto la stiamo aspettando}}

**Palla ferma:** {{se non si capisce di chi sia, scriverlo qui. Altrimenti togliere la riga.}}

## Buchi

{{Cosa non sono riuscito a ricostruire, e quale materiale servirebbe. Se non manca niente, scrivere "niente di rilevante".}}
