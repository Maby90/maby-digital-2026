"""
Generatore di lavagne Excalidraw — freebie Maby Prochilo.
Uso come libreria:  from lavagne import *

Produce file .excalidraw validi (schema version 2) importabili
con drag & drop su https://excalidraw.com.
Solo standard library, nessuna dipendenza esterna.
"""

import json
import math
import os
import random
import string
import time

# ── Palette brand ────────────────────────────────────────────────────────────
TERRACOTTA  = "#C65D07"   # accento, filo rosso — usare con parsimonia
INK         = "#2D2A26"   # testo e bordi principali
CREAM       = "#F5F0E8"   # sfondo box contenuto
OLIVE       = "#7A8471"   # accento secondario, connettori, etichette
SAND        = "#EBE4DC"   # sfondo alternativo, righe pari/dispari
WHITE       = "#FFFFFF"   # testo su fondo scuro
CLEAR       = "transparent"
PAPER       = "#FFFDF9"   # sfondo della lavagna

# ── Font (fontFamily di Excalidraw) ──────────────────────────────────────────
# 1 = Excalifont/Virgil (hand-drawn), 2 = Helvetica, 3 = Cascadia,
# 5 = Nunito, 6 = Lilita One, 7 = Comic Shanns
NUNITO = 5          # font di default di questa skill
FONT_DEFAULT = NUNITO

# ── Dimensioni tipografiche ──────────────────────────────────────────────────
SIZE_TITLE   = 28
SIZE_HEADING = 20
SIZE_BODY    = 16
SIZE_SMALL   = 12


# ── Helper di basso livello ──────────────────────────────────────────────────

def _uid(n=20):
    return "".join(random.choices(string.ascii_letters + string.digits, k=n))

def _seed():
    return random.randint(1_000_000, 9_999_999)

def _now_ms():
    return int(time.time() * 1000)

def _common(el_id=None):
    return {
        "id": el_id or _uid(),
        "angle": 0,
        "opacity": 100,
        "groupIds": [],
        "frameId": None,
        "roundness": None,
        "version": 1,
        "versionNonce": _seed(),
        "isDeleted": False,
        "boundElements": None,
        "updated": _now_ms(),
        "link": None,
        "locked": False,
        "seed": _seed(),
    }

def _stroke(color=INK, bg=CLEAR, fill="hachure",
            width=2, style="solid", roughness=1):
    return {
        "strokeColor": color,
        "backgroundColor": bg,
        "fillStyle": fill,
        "strokeWidth": width,
        "strokeStyle": style,
        "roughness": roughness,
    }


# ── Testo ────────────────────────────────────────────────────────────────────

def _inner_text(container_id, cx, cy, cw, ch, content,
                size=SIZE_BODY, color=INK, font=FONT_DEFAULT):
    """Testo legato (bound) al centro di un container."""
    w = cw * 0.85
    h = ch * 0.85
    return {
        **_common(),
        **_stroke(color=color, fill="solid", width=1, roughness=0),
        "type": "text",
        "x": cx + (cw - w) / 2,
        "y": cy + (ch - h) / 2,
        "width": w,
        "height": h,
        "backgroundColor": CLEAR,
        "text": content,
        "originalText": content,
        "fontSize": size,
        "fontFamily": font,
        "textAlign": "center",
        "verticalAlign": "middle",
        "containerId": container_id,
        "autoResize": True,
        "lineHeight": 1.25,
    }

def text(x, y, content, size=SIZE_BODY, color=INK,
         align="center", font=FONT_DEFAULT):
    """Testo libero. Con align='center', x è il centro orizzontale."""
    lines = content.split("\n")
    longest = max((len(l) for l in lines), default=0)
    est_w = max(longest * size * 0.55, 40)
    est_h = len(lines) * size * 1.4
    return {
        **_common(),
        **_stroke(color=color, fill="solid", width=1, roughness=0),
        "type": "text",
        "x": x - est_w / 2 if align == "center" else x,
        "y": y - est_h / 2,
        "width": est_w,
        "height": est_h,
        "backgroundColor": CLEAR,
        "text": content,
        "originalText": content,
        "fontSize": size,
        "fontFamily": font,
        "textAlign": align,
        "verticalAlign": "middle",
        "containerId": None,
        "autoResize": True,
        "lineHeight": 1.25,
    }


# ── Forme ────────────────────────────────────────────────────────────────────

def _shape(kind, x, y, w, h, label, bg, stroke, roughness,
           rounded, size, font_color, fill):
    font_color = font_color or stroke
    el_id = _uid()
    el = {
        **_common(el_id),
        **_stroke(color=stroke, bg=bg, fill=fill, roughness=roughness),
        "type": kind,
        "x": x, "y": y, "width": w, "height": h,
    }
    if kind == "rectangle":
        el["roundness"] = {"type": 3} if rounded else None
    out = [el]
    if label:
        t = _inner_text(el_id, x, y, w, h, label, size=size, color=font_color)
        el["boundElements"] = [{"type": "text", "id": t["id"]}]
        out.append(t)
    return out

def box(x, y, w, h, label=None, bg=CREAM, stroke=INK, roughness=1,
        rounded=True, size=SIZE_BODY, font_color=None, fill="hachure"):
    return _shape("rectangle", x, y, w, h, label, bg, stroke,
                  roughness, rounded, size, font_color, fill)

def oval(x, y, w, h, label=None, bg=CREAM, stroke=INK, roughness=1,
         size=SIZE_BODY, font_color=None, fill="hachure"):
    return _shape("ellipse", x, y, w, h, label, bg, stroke,
                  roughness, False, size, font_color, fill)

def rhombus(x, y, w, h, label=None, bg=CREAM, stroke=INK, roughness=1,
            size=SIZE_BODY, font_color=None, fill="hachure"):
    return _shape("diamond", x, y, w, h, label, bg, stroke,
                  roughness, False, size, font_color, fill)


# ── Connettori ───────────────────────────────────────────────────────────────

def arrow(x1, y1, x2, y2, color=INK, dashed=False, width=2,
          end_head="arrow", start_head=None, roughness=1):
    dx, dy = x2 - x1, y2 - y1
    return {
        **_common(),
        **_stroke(color=color, width=width, roughness=roughness,
                  style="dashed" if dashed else "solid"),
        "type": "arrow",
        "x": x1, "y": y1,
        "width": abs(dx), "height": abs(dy),
        "points": [[0, 0], [dx, dy]],
        "startArrowhead": start_head,
        "endArrowhead": end_head,
        "startBinding": None,
        "endBinding": None,
        "elbowed": False,
        "backgroundColor": CLEAR,
    }

def connector(x1, y1, x2, y2, color=OLIVE, dashed=False, width=1, roughness=1):
    dx, dy = x2 - x1, y2 - y1
    return {
        **_common(),
        **_stroke(color=color, width=width, roughness=roughness,
                  style="dashed" if dashed else "solid"),
        "type": "line",
        "x": x1, "y": y1,
        "width": abs(dx), "height": abs(dy),
        "points": [[0, 0], [dx, dy]],
        "startArrowhead": None,
        "endArrowhead": None,
        "backgroundColor": CLEAR,
    }


# ── Intestazione ─────────────────────────────────────────────────────────────

def heading(title, canvas_w=900, title_y=45, rule_y=72):
    """Titolo centrato + riga terracotta sotto. Primo elemento di ogni lavagna."""
    return [
        text(canvas_w / 2, title_y, title, size=SIZE_TITLE, color=INK, align="center"),
        connector(80, rule_y, canvas_w - 80, rule_y, color=TERRACOTTA,
                  width=2, roughness=0),
    ]


# ── Layout: gli 8 tipi di lavagna ────────────────────────────────────────────

def flow_h(items, start_x=80, y=200, w=160, h=80, gap=60,
           bg=CREAM, stroke=INK, size=SIZE_BODY):
    """1. Flusso lineare orizzontale: box collegati sinistra→destra."""
    out, prev_right = [], None
    for i, label in enumerate(items):
        x = start_x + i * (w + gap)
        out += box(x, y, w, h, label=label, bg=bg, stroke=stroke, size=size)
        if prev_right is not None:
            out.append(arrow(prev_right, y + h / 2, x, y + h / 2, color=INK))
        prev_right = x + w
    return out

def flow_v(items, x=340, start_y=80, w=200, h=70, gap=50,
           bg=CREAM, stroke=INK, size=SIZE_BODY):
    """1b. Flusso lineare verticale: box collegati alto→basso."""
    out, prev_bottom = [], None
    for i, label in enumerate(items):
        y = start_y + i * (h + gap)
        out += box(x, y, w, h, label=label, bg=bg, stroke=stroke, size=size)
        if prev_bottom is not None:
            out.append(arrow(x + w / 2, prev_bottom, x + w / 2, y, color=INK))
        prev_bottom = y + h
    return out

def compare(left_title, right_title, left_items, right_items,
            x=80, y=120, col_w=220, row_h=55, header_h=60, gap=40):
    """2. Confronto X vs Y: due colonne con header colorati."""
    out = []
    right_x = x + col_w + gap
    out += box(x, y, col_w, header_h, label=left_title, bg=INK, stroke=INK,
               font_color=WHITE, fill="solid", size=SIZE_HEADING)
    out += box(right_x, y, col_w, header_h, label=right_title, bg=TERRACOTTA,
               stroke=TERRACOTTA, font_color=WHITE, fill="solid", size=SIZE_HEADING)
    for i, (l, r) in enumerate(zip(left_items, right_items)):
        row_y = y + header_h + i * row_h
        alt = CREAM if i % 2 == 0 else SAND
        out += box(x, row_y, col_w, row_h, label=l, bg=alt, stroke=INK, size=SIZE_BODY)
        out += box(right_x, row_y, col_w, row_h, label=r, bg=alt, stroke=INK, size=SIZE_BODY)
    return out

def hub(center, spokes, cx=450, cy=380, hub_w=160, hub_h=80,
        spoke_w=140, spoke_h=65, radius=220, size=SIZE_BODY):
    """3. Hub & spoke: nucleo terracotta + satelliti crema."""
    out = []
    out += box(cx - hub_w / 2, cy - hub_h / 2, hub_w, hub_h, label=center,
               bg=TERRACOTTA, stroke=TERRACOTTA, font_color=WHITE,
               fill="solid", size=size)
    n = len(spokes)
    for i, label in enumerate(spokes):
        a = 2 * math.pi * i / n - math.pi / 2
        sx = cx + radius * math.cos(a) - spoke_w / 2
        sy = cy + radius * math.sin(a) - spoke_h / 2
        out += box(sx, sy, spoke_w, spoke_h, label=label, bg=CREAM,
                   stroke=INK, size=size)
        out.append(connector(cx, cy, sx + spoke_w / 2, sy + spoke_h / 2,
                             color=OLIVE, width=1))
    return out

def matrix(q_tl, q_tr, q_bl, q_br, axis_x="", axis_y="",
           x=140, y=110, size=320):
    """4. Matrix 2x2. Argomenti in ordine di lettura: alto-sx, alto-dx, basso-sx, basso-dx."""
    out = []
    half = size // 2
    quads = [
        (x,        y,        q_tl),
        (x + half, y,        q_tr),
        (x,        y + half, q_bl),
        (x + half, y + half, q_br),
    ]
    for qx, qy, label in quads:
        out += box(qx, qy, half, half, label=label, bg=CREAM, stroke=INK, size=SIZE_BODY)
    if axis_x:
        out.append(text(x + size / 2, y + size + 34, axis_x, size=SIZE_SMALL, color=OLIVE))
        out.append(arrow(x + 10, y + size + 20, x + size - 10, y + size + 20,
                        color=OLIVE, width=1))
    if axis_y:
        out.append(text(x - 42, y + size / 2, axis_y, size=SIZE_SMALL, color=OLIVE))
        out.append(arrow(x - 26, y + size - 10, x - 26, y + 10, color=OLIVE, width=1))
    return out

def timeline(events, start_x=100, line_y=300, canvas_w=900,
             color=INK, accent=TERRACOTTA):
    """5. Timeline orizzontale. events: [{"tag": "2020", "label": "..."}]. Alterna sopra/sotto."""
    out = []
    n = len(events)
    step = (canvas_w - 2 * start_x) / max(n - 1, 1)
    out.append(connector(start_x, line_y, canvas_w - start_x, line_y, color=color, width=2))
    for i, ev in enumerate(events):
        ex = start_x + i * step
        above = (i % 2 == 0)
        out += oval(ex - 8, line_y - 8, 16, 16, bg=accent, stroke=accent,
                    roughness=0, fill="solid")
        tag_y = line_y - 28 if above else line_y + 18
        out.append(text(ex, tag_y, ev.get("tag", ""), size=SIZE_SMALL, color=OLIVE))
        lbl_y = line_y - 80 if above else line_y + 66
        out.append(text(ex, lbl_y, ev.get("label", ""), size=SIZE_BODY, color=color))
        y1 = line_y - 16 if above else line_y + 16
        y2 = line_y - 40 if above else line_y + 40
        out.append(connector(ex, y1, ex, y2, color=OLIVE, width=1, dashed=True))
    return out

def pyramid(levels, cx=450, base_y=520, level_h=70, base_w=440,
            shrink=90, bg=CREAM, stroke=INK, size=SIZE_BODY):
    """6. Piramide/gerarchia. levels dal basso (base) all'alto (apice)."""
    out = []
    for i, label in enumerate(levels):
        w = base_w - i * shrink
        y = base_y - i * level_h
        x = cx - w / 2
        tint = TERRACOTTA if i == len(levels) - 1 else bg
        fcol = WHITE if i == len(levels) - 1 else INK
        fill = "solid" if i == len(levels) - 1 else "hachure"
        out += box(x, y, w, level_h - 8, label=label, bg=tint, stroke=stroke,
                   font_color=fcol, fill=fill, size=size)
    return out

def before_after(before_label, after_label, before_items, after_items,
                 x=80, y=140, panel_w=280, panel_h=240, gap=120):
    """7. Prima/Dopo: due pannelli separati da freccia centrale."""
    out = []
    right_x = x + panel_w + gap
    out += box(x, y, panel_w, panel_h, bg=SAND, stroke=INK, roughness=1)
    out.append(text(x + panel_w / 2, y + 26, before_label, size=SIZE_HEADING, color=INK))
    for i, it in enumerate(before_items):
        out.append(text(x + 20, y + 60 + i * 28, it, size=SIZE_BODY, color=INK, align="left"))
    out += box(right_x, y, panel_w, panel_h, bg=CREAM, stroke=TERRACOTTA, roughness=1)
    out.append(text(right_x + panel_w / 2, y + 26, after_label, size=SIZE_HEADING, color=TERRACOTTA))
    for i, it in enumerate(after_items):
        out.append(text(right_x + 20, y + 60 + i * 28, it, size=SIZE_BODY, color=INK, align="left"))
    mid_y = y + panel_h / 2
    out.append(arrow(x + panel_w + 20, mid_y, right_x - 20, mid_y,
                    color=TERRACOTTA, width=3))
    return out

def loop(nodes, cx=450, cy=360, radius=190, node_w=150, node_h=64,
         bg=CREAM, stroke=INK, arrow_color=OLIVE, size=SIZE_BODY):
    """8. Ciclo/loop: nodi in cerchio con frecce da uno al successivo."""
    out = []
    n = len(nodes)
    centers = []
    for i, label in enumerate(nodes):
        a = 2 * math.pi * i / n - math.pi / 2
        ncx = cx + radius * math.cos(a)
        ncy = cy + radius * math.sin(a)
        centers.append((ncx, ncy))
        out += box(ncx - node_w / 2, ncy - node_h / 2, node_w, node_h,
                   label=label, bg=bg, stroke=stroke, size=size)
    for i in range(n):
        x1, y1 = centers[i]
        x2, y2 = centers[(i + 1) % n]
        out.append(arrow(x1, y1, x2, y2, color=arrow_color, width=2))
    return out


# ── Assemblaggio e salvataggio ───────────────────────────────────────────────

def scene(elements, bg=PAPER):
    """Appiattisce liste annidate e produce il documento Excalidraw."""
    flat = []
    def walk(items):
        for it in items:
            if isinstance(it, list):
                walk(it)
            elif isinstance(it, dict):
                flat.append(it)
    walk(elements)
    return {
        "type": "excalidraw",
        "version": 2,
        "source": "https://excalidraw.com",
        "elements": flat,
        "appState": {"gridSize": 20, "viewBackgroundColor": bg},
        "files": {},
    }

def save(doc, path):
    """Scrive il file .excalidraw su disco (crea le cartelle mancanti)."""
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
    print(f"OK  {path}")
    return path


if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/lavagna-demo.excalidraw"
    demo = [
        heading("Demo — generatore lavagne", canvas_w=900),
        flow_h(["Input", "Elaborazione", "Output"], start_x=170, y=180, gap=90),
        hub("Nucleo", ["Tema A", "Tema B", "Tema C", "Tema D"], cx=450, cy=470, radius=170),
    ]
    save(scene(demo), out)
