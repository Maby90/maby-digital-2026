# Lavagne Excalidraw — la skill

Questa skill genera lavagne e schemi visivi in formato `.excalidraw`: flussi,
confronti, timeline, mappe, piramidi, cicli. I file si aprono gratis su
[excalidraw.com](https://excalidraw.com), senza account, trascinandoli nella
finestra del browser.

## Cosa ti serve

- **Claude** con Claude Code (o un ambiente dove puoi eseguire skill e Python 3).
- Nient'altro: lo script usa solo la libreria standard di Python, zero
  installazioni.

## Installazione in 3 passi

1. **Scompatta** questo zip. Ottieni una cartella `lavagne-excalidraw-freebie/`
   con dentro `SKILL.md`, questo README e la cartella `scripts/`.
2. **Mettila tra le tue skill.** Copia l'intera cartella nella directory delle
   skill del tuo workspace Claude (di solito `skills/`). Se non sai dove sia,
   chiedi a Claude: "dove metto una nuova skill in questo workspace?".
3. **Attivala.** In una chat con Claude scrivi: "usa la skill lavagne-excalidraw
   e creami uno schema su [il tuo argomento]". Claude legge `SKILL.md`, sceglie
   il tipo di schema adatto e genera il file.

## Come si usa, in pratica

Dì a Claude cosa vuoi visualizzare. Esempi:

- "Fammi una timeline dell'evoluzione dei modelli AI dal 2020."
- "Uno schema hub & spoke con al centro 'brand voice' e intorno i 4 elementi
  che la compongono."
- "Un confronto a due colonne: fare da soli vs delegare a un sistema."

Claude produce un file `.excalidraw`. Aprilo su excalidraw.com trascinandolo
nella finestra: è già editabile, puoi spostare tutto, cambiare colori e testi.

## Personalizzare

Tutto è in `scripts/lavagne.py`. In alto trovi la palette (colori) e il font.
Il font di default è **Nunito**; se vuoi il classico look "scritto a mano"
cambia `FONT_DEFAULT = NUNITO` in `FONT_DEFAULT = 1` (Excalifont).

## Da dove arriva

L'ha costruita Maby Prochilo, che scrive di AI applicata al marketing e
all'automazione su **Oltre il prompt**:
[oltreilprompt.substack.com](https://oltreilprompt.substack.com).
