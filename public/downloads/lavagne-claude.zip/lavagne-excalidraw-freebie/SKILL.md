---
name: lavagne-excalidraw
description: >
  Genera lavagne e schemi visivi in formato .excalidraw, pronti da importare
  su excalidraw.com con un drag & drop. Usa questa skill quando serve un
  diagramma, un flusso, un confronto, una timeline, una matrice, un ciclo,
  una piramide o una mappa concettuale da mettere in una newsletter, un post
  o una presentazione. Trigger: schema, lavagna, diagramma, flusso, confronto,
  timeline, framework visivo, mappa concettuale, "fammi vedere come funziona X".
---

# Skill: lavagne Excalidraw

Genera file `.excalidraw` validi in stile hand-drawn editoriale. Il font di
default è Nunito, l'accento è terracotta. I file si aprono su
[excalidraw.com](https://excalidraw.com) trascinandoli nella finestra.

## Come funziona

Lo script `scripts/lavagne.py` è una libreria Python (solo standard library).
Si importa, si definiscono gli elementi con coordinate, si chiama `scene()` e
`save()`. Nessun JSON scritto a mano: gli ID e i seed vengono generati soli.

## Workflow

### 1. Scegli il tipo di lavagna

Parti dal concetto e scegli lo schema. In caso di dubbio, usa **hub & spoke**.

| Tipo | Funzione Python | Quando |
|------|-----------------|--------|
| Flusso lineare | `flow_h` / `flow_v` | passaggi ordinati, processi |
| Confronto | `compare` | X vs Y, prima/dopo a colonne |
| Hub & spoke | `hub` | concetto centrale + satelliti |
| Matrix 2x2 | `matrix` | due assi, quadranti |
| Timeline | `timeline` | evoluzione nel tempo |
| Piramide | `pyramid` | gerarchia, livelli, priorità |
| Prima/Dopo | `before_after` | trasformazione, impatto |
| Ciclo | `loop` | feedback loop, iterazioni |

### 2. Pianifica il layout

Il canvas ha `x` che cresce a destra e `y` verso il basso. Lavora su una
larghezza di 800-1000px, margini minimi 60px, spaziatura minima 40px tra i
bordi. Punto di partenza tipico: `x=80, y=80`.

Ogni lavagna inizia con `heading("Titolo", canvas_w=...)`: titolo centrato più
riga terracotta.

### 3. Genera

```bash
python3 - << 'EOF'
import sys
sys.path.insert(0, 'skills/lavagne-excalidraw-freebie/scripts')
from lavagne import *

doc = scene([
    heading("Il mio schema", canvas_w=900),
    hub("Centro", ["Tema A", "Tema B", "Tema C", "Tema D"], cx=450, cy=420),
])
save(doc, "lavagna.excalidraw")
EOF
```

### 4. Consegna

Verifica che il file esista, poi: apri excalidraw.com e trascina il file nella
finestra. Lo schema si carica già editabile.

## Palette

| Nome | Hex | Uso |
|------|-----|-----|
| Terracotta | `#C65D07` | accento, filo rosso — con parsimonia |
| Ink | `#2D2A26` | testo e bordi |
| Cream | `#F5F0E8` | sfondo box |
| Olive | `#7A8471` | connettori, etichette |
| Sand | `#EBE4DC` | righe alternate |
| Paper | `#FFFDF9` | sfondo lavagna |

## Regole

- Max 15-20 elementi per lavagna: meglio 8 chiari che 20 affollati.
- Font Nunito di default (`NUNITO`, cioè `fontFamily=5`). Non cambiarlo senza motivo.
- Titolo in alto sempre presente (`heading`).
- Testo che non sta nel box: allarga il box o accorcia il testo.
- Terracotta solo come accento, mai come colore dominante.
